class Solution { 
public: 
    bool isPalindrome(int x) { 
        string s = to_string(x); 
          int i = 0 ; 
          int j = s.length() - 1 ; 
          for ( i = 0 ; i <= j / 2 ; i++ ) { 
            if ( s[ i ] != s[ s.length() - i - 1 ] ) { 
return false ;  
     } 
          } 
     return true ; 
    } 
}; 