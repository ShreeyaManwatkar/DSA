package Tasks;

import java.util.ArrayList;



public class Task11 {
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("Yuvi");
		list.add("Sonu");
		list.add("Aarya");
		list.add("Vinayak");
		
		
		System.out.println(list.reversed());
	}
}
	

	

