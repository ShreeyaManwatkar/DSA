package Tasks;

import java.util.Vector;

public class Task13 {
	public static void main(String[] args) {
		Vector<String> Mercedes = new Vector<String>();
		Mercedes.add("S-Class");
		Mercedes.add("E-Class");
		Mercedes.add("G-Wagon");
		
		System.out.println(Mercedes);
	}
}
