package DSAJava;

import java.util.HashSet;

public class SimpleHashSet {

	public static void main(String[] args) {
		HashSet<String> names = new HashSet<String>();
		
		names.add("yuvi");
		names.add("yuvi");
		names.add("sonu");
		names.add("shravani");
		names.add("grace");
		
		System.out.println(names);
	}

}
