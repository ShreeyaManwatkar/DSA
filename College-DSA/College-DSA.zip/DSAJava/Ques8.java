package DSAJava;

import java.util.HashMap;
import java.util.Scanner;

//public class CharFrequencyCounter {
	public class Ques8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take input from the user
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        // Create a HashMap to store character frequencies
        HashMap<Character, Integer> charCountMap = new HashMap<>();

        // Loop through each character in the string
        for (char ch : input.toCharArray()) {
            // Skip counting spaces (optional)
            if (ch == ' ') continue;

            // Update count in HashMap
            if (charCountMap.containsKey(ch)) {
                charCountMap.put(ch, charCountMap.get(ch) + 1);
            } else {
                charCountMap.put(ch, 1);
            }
        }

        // Display the results
        System.out.println("\nCharacter Frequencies:");
        for (char ch : charCountMap.keySet()) {
            System.out.println(ch + " : " + charCountMap.get(ch));
        }

        scanner.close();
    }
}

