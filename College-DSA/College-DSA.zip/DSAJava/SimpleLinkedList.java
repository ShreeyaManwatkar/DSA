package DSAJava;

import java.util.Collections;
import java.util.LinkedList;

public class SimpleLinkedList {

	public static void main(String[] args) {
		LinkedList<Integer> numbers = new LinkedList<Integer>();
		LinkedList<String> names = new LinkedList<String>();
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		numbers.add(50);
		numbers.add(40);
		
		names.add("Alice");
		names.add("in");
		names.add("the");
		names.add("wonder");
		names.add("land");
		
		System.out.println(numbers);
		System.out.println(names);
		
		
		Collections.sort(names);
		Collections.sort(numbers);
		
	}

}