package DSAJava;

public class TraverseArray { //TraverseArray -  going through / finding, each element on by one.
	public static void main(String[] args) {
		
	
	int [] marks = new int [3];
	marks[0] = 90;
	marks[1] = 94;
	marks[2] = 99;
	
	System.out.println(marks[1]);

	}
}
